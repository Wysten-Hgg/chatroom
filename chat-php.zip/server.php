<?php
/**
 * Created by PhpStorm.
 * User: Hanson
 * Date: 2017/8/16
 * Time: 10:09
 */

require_once './config/config.php';


$ws =  new  \Config\config('0.0.0.0',9503);

$ws->set(array(
    'daemonize'       => 0,
    'worker_num'      => 2, //worker process num
    'task_worker_num' => 2
//    'log_file'      => '/home/buff/swoole.log'
));
$redis = null;
$ws->on('WorkerStart', function ($ws, $worker_id) {
    global $redis;
    $redis = new \Redis();
    $redis->connect("127.0.0.1", 6379) || die("redis 连接失败");
    echo "进程{$worker_id}的redis 连接成功!\n";
});


$ws->on('open', function ($ws, $request) {
    global $redis;
    $ws->open($redis,$request);
});