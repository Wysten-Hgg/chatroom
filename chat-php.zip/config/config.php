<?php
/**
 * Created by PhpStorm.
 * User: Hanson
 * Date: 2017/8/16
 * Time: 10:01
 */
namespace Config;

class config extends \swoole_websocket_server{
    const NEWUSER='NEW';
    public function open(\Redis $redis,$frame){
        $name=$frame->get('name');
        $redis->hMset($frame->fd,["name" => $name, "ip" => $frame->server['remote_addr']]);
        $this->send_message($redis,$frame,self::NEWUSER);
    }
    public function send_message(\Redis $redis,$frame,$message_type){
        switch($message_type){
            case self::NEWUSER:
                $start_fd = 0;
                while(true)
                {
                    // connection_list函数获取现在连接中的fd
                    $conn_list = $this->connection_list($start_fd, 100);   // 获取从fd之后一百个进行发送

                    $start_fd = end($conn_list);

                    foreach($conn_list as $fd)
                    {
                        $result[]=$redis->hGetAll($fd);
                    }
                }
                $result['type']=0;
                $msg=json_encode($result);
                $this->push($frame->fd,$msg);
                break;
        }
    }
}